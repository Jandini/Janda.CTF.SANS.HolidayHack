# mt19937
Code for creating, using, and cloning MT19937 Mersenne Twister PRNGs
